# HBRS beamer template

[![Build Status](https://travis-ci.org/mas-group/beamer-template.svg?branch=master)](https://travis-ci.org/mas-group/beamer-template)

You can add a third party logo by using the command `\thirdpartylogo{path/to/your/image}`.

Heavily adapted from [Masaryk University beamper template](https://www.overleaf.com/latex/templates/fibeamer-for-the-faculty-of-arts-at-the-masaryk-university-in-brno/rbtxqwnjyndf).
